import java.util.Scanner;

public class PasswordLengthChecker {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a password: ");
        String password = input.nextLine();
        int length = password.length();

        if (length < 8) {
            System.out.println("Password status: Less than 8 characters.");
        } else if (length <= 11) {
            System.out.println("Password status: Acceptable.");
        } else {
            System.out.println("Password status: Strong.");
        }

        input.close();
    }
}
