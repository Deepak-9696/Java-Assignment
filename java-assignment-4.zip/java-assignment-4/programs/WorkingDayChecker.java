import java.util.Scanner;

public class WorkingDayChecker {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a day number (1-7): ");
        int day = input.nextInt();

        if (day >= 1 && day <= 5) {
            System.out.println("It is a working day.");
        } else if (day == 6 || day == 7) {
            System.out.println("It is the weekend.");
        } else {
            System.out.println("Invalid day number. Please enter a number from 1 to 7.");
        }

        input.close();
    }
}
