import java.util.Scanner;

public class DivisibilityChecker {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = input.nextInt();

        if (number % 5 == 0) {
            System.out.println("The number is divisible by 5.");

            if (number % 10 == 0) {
                System.out.println("The number is also divisible by 10.");
            } else {
                System.out.println("The number is not divisible by 10.");
            }
        } else {
            System.out.println("The number is not divisible by 5.");
        }

        input.close();
    }
}
