from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path('/home/ubuntu/conditional_programs')
PROGRAMS = ROOT / 'programs'
OUTPUTS = ROOT / 'outputs'
SCREENSHOTS = ROOT / 'screenshots'
DOCUMENT = ROOT / 'document'
SCREENSHOTS.mkdir(exist_ok=True)

try:
    mono = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 26)
    mono_small = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 21)
except OSError:
    mono = ImageFont.load_default()
    mono_small = mono

# Create readable terminal-style screenshots for each tested output.
for index in range(1, 6):
    output_path = OUTPUTS / f'problem{index}.txt'
    lines = output_path.read_text().splitlines()
    lines = [line for line in lines if line.strip()]
    width = 1500
    line_height = 40
    height = max(220, 100 + line_height * len(lines))
    image = Image.new('RGB', (width, height), '#111827')
    draw = ImageDraw.Draw(image)
    draw.rectangle((0, 0, width, 58), fill='#1f2937')
    draw.ellipse((22, 21, 38, 37), fill='#ef4444')
    draw.ellipse((48, 21, 64, 37), fill='#f59e0b')
    draw.ellipse((74, 21, 90, 37), fill='#22c55e')
    draw.text((120, 17), f'Java Program {index} - Output', font=mono_small, fill='#e5e7eb')
    y = 82
    for line in lines:
        draw.text((35, y), line, font=mono, fill='#d1fae5')
        y += line_height
    image.save(SCREENSHOTS / f'problem{index}_output.png')


def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:fill'), fill)
    tc_pr.append(shd)


def add_code_block(document, code):
    table = document.add_table(rows=1, cols=1)
    table.autofit = True
    cell = table.cell(0, 0)
    set_cell_shading(cell, 'F3F4F6')
    paragraph = cell.paragraphs[0]
    paragraph.paragraph_format.space_after = Pt(0)
    run = paragraph.add_run(code)
    run.font.name = 'Courier New'
    run.font.size = Pt(8.5)


doc = Document()
section = doc.sections[0]
section.top_margin = Inches(0.7)
section.bottom_margin = Inches(0.7)
section.left_margin = Inches(0.8)
section.right_margin = Inches(0.8)

styles = doc.styles
styles['Normal'].font.name = 'Calibri'
styles['Normal'].font.size = Pt(11)

heading = doc.add_paragraph()
heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = heading.add_run('Java Conditional Statements Assignment')
run.bold = True
run.font.size = Pt(22)
run.font.color.rgb = RGBColor(31, 78, 121)
subtitle = doc.add_paragraph()
subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
subtitle.add_run('Five beginner-level programs using if, else-if, and nested if statements').italic = True

info = doc.add_table(rows=3, cols=2)
info.style = 'Table Grid'
for row, label in zip(info.rows, ['Student Name', 'Course / Section', 'Submission Date']):
    row.cells[0].text = label
    row.cells[1].text = '[Fill in before submitting]'
    set_cell_shading(row.cells[0], 'D9EAF7')
    row.cells[0].paragraphs[0].runs[0].bold = True

doc.add_paragraph('Introduction', style='Heading 1')
doc.add_paragraph('This assignment demonstrates how conditional statements can be used to make decisions in Java. Each program accepts input from the user, evaluates one or more conditions, and displays a clear result. The output screenshots below were produced by compiling and running the corresponding Java source files.')

doc.add_paragraph('Programs Included', style='Heading 1')
summary = doc.add_table(rows=1, cols=3)
summary.style = 'Table Grid'
for cell, text in zip(summary.rows[0].cells, ['No.', 'Program', 'Main decision being tested']):
    cell.text = text
    set_cell_shading(cell, '1F4E79')
    for r in cell.paragraphs[0].runs:
        r.bold = True
        r.font.color.rgb = RGBColor(255, 255, 255)
items = [
    ('1', 'EvenOddPositiveNegative', 'Positive, negative, zero, even, or odd'),
    ('2', 'LargestOfThreeNumbers', 'Largest value among three numbers'),
    ('3', 'DivisibilityChecker', 'Divisible by 5 and, if so, by 10'),
    ('4', 'WorkingDayChecker', 'Working day, weekend, or invalid input'),
    ('5', 'PasswordLengthChecker', 'Less than 8 characters, acceptable, or strong'),
]
for item in items:
    cells = summary.add_row().cells
    for cell, text in zip(cells, item):
        cell.text = text

for index, (class_name, title, explanation) in enumerate([
    ('EvenOddPositiveNegative', 'Problem 1: Check Even/Odd and Positive/Negative', 'The program first determines whether the number is positive, negative, or zero. For nonzero values, it uses the remainder operator to determine whether the value is even or odd.'),
    ('LargestOfThreeNumbers', 'Problem 2: Largest of Three Numbers', 'The program compares each value with the other two values using an if-else-if-else structure. The greatest value is stored in the largest variable and displayed.'),
    ('DivisibilityChecker', 'Problem 3: Number Divisibility Checker', 'The program first checks divisibility by 5. Only when that condition is true does a nested condition check divisibility by 10.'),
    ('WorkingDayChecker', 'Problem 4: Check Working Day', 'Day numbers 1 through 5 are treated as working days, 6 and 7 are treated as the weekend, and any other number is rejected as invalid.'),
    ('PasswordLengthChecker', 'Problem 5: Password Length Checker', 'The program measures the number of characters in the password. Fewer than 8 characters is reported as less than 8, 8 through 11 characters is acceptable, and 12 or more characters is strong.'),
]):
    doc.add_page_break()
    doc.add_paragraph(title, style='Heading 1')
    doc.add_paragraph(explanation)
    doc.add_paragraph('Java Source Code', style='Heading 2')
    add_code_block(doc, (PROGRAMS / f'{class_name}.java').read_text())
    doc.add_paragraph('Program Output Screenshot', style='Heading 2')
    picture = doc.add_picture(str(SCREENSHOTS / f'problem{index + 1}_output.png'), width=Inches(6.5))
    picture.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph(f'Test case used: see the input shown in the output screenshot for Problem {index + 1}.')

out = DOCUMENT / 'Java_Conditional_Statements_Assignment.docx'
doc.save(out)
print(out)
